#version 330 compatibility

#include "/program/gbuffers_clouds.vsh"
